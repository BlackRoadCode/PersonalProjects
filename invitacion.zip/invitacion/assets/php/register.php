<?php

session_start();

// connect to the database
$db = mysqli_connect('localhost', 'darkcodr_invitacion', 'invitacion38@', 'darkcodr_invitacion');
// $db = mysqli_connect('localhost', 'root', '', 'refer_a_friend');

$inputName = $_POST['inputNombre'];
$inputAcompaniantes = $_POST['inputAcompaniantes'];

$query = "INSERT INTO registers ( id, nombre, acompaniantes )
  VALUES ('','".$inputName."', '".$inputAcompaniantes."')";

mysqli_query($db, $query);

header('Location: https://darkcod3r.com/invitacion/gracias.html');

?>